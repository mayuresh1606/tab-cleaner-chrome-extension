let tabActivity = {};

chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.remove('inactiveTabs');
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.remove('inactiveTabs');
});

chrome.tabs.onActivated.addListener(activeInfo => {
  const tabId = activeInfo.tabId;
  const timestamp = Date.now();
  chrome.storage.local.set({ [tabId]: timestamp });
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) return;

  chrome.tabs.query({ active: true, windowId }, (tabs) => {
    if (tabs[0]) {
      chrome.storage.local.set({ [tabs[0].id]: Date.now() });
    }
  });
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.local.get('inactiveTabs', data => {
    const updatedList = (data.inactiveTabs || []).filter(tab => tab.id !== tabId);
    chrome.storage.local.set({ inactiveTabs: updatedList });
  });
  chrome.storage.local.remove(tabId.toString());
});


chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    chrome.storage.local.set({ [tabId]: Date.now() });
  }
});


chrome.alarms.create('checkTabs', { periodInMinutes: 5 });
// chrome.alarms.create('checkTabs', { periodInMinutes: 1 }); // for testing

chrome.alarms.onAlarm.addListener(() => {
  chrome.storage.sync.get(['INACTIVITY_LIMIT_MS', 'NOTIFICATIONS_ENABLED'], (settings) => {
    const threshold = (settings.INACTIVITY_LIMIT_MS || 120); // default 120 minutes
    const showNotification = settings.NOTIFICATIONS_ENABLED !== false;
    chrome.tabs.query({}, tabs => {
      const now = Date.now();
      const inactiveTabs = [];

      tabs.forEach(tab => {
        const lastActive = tab.lastAccessed || 0;
        if ((now - lastActive) > threshold && !tab.active && tab.url.startsWith("http")) {
          inactiveTabs.push({
            id: tab.id,
            title: tab.title || tab.url,
            url: tab.url
          });
        }
      });

      if (inactiveTabs.length > 0) {
        // Filter out tabs that no longer exist
        chrome.tabs.query({}, openTabs => {
          const openTabIds = openTabs.map(t => t.id);
          const validInactiveTabs = inactiveTabs.filter(t => openTabIds.includes(t.id));
          
          chrome.storage.local.set({ inactiveTabs: validInactiveTabs });

          if (showNotification && validInactiveTabs.length > 0) {
            chrome.notifications.create('inactiveTabs', {
              type: 'basic',
              iconUrl: 'icon.png',
              title: 'Inactive Tabs Detected',
              message: `You have ${validInactiveTabs.length} tab(s) idle for a while. Click to review.`,
              priority: 2
            });
          }
        });
      }
    });
  });
});

chrome.notifications.onClicked.addListener((notifId) => {
  if (notifId === 'inactiveTabs') {
    chrome.windows.create({
      url: "popup.html",
      type: "popup",
      width: 400,
      height: 600
    });
  }
});
