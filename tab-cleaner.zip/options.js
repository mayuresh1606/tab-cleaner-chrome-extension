document.addEventListener("DOMContentLoaded", () => {
  const timeLimitInput = document.getElementById("timeLimit");
  const notificationsToggle = document.getElementById("notificationsToggle");

  // Fetch saved settings
  chrome.storage.sync.get(["INACTIVITY_LIMIT_MS", "NOTIFICATIONS_ENABLED"], (data) => {
    // Set default time limit in minutes
    const defaultMinutes = data.INACTIVITY_LIMIT_MS
      ? data.INACTIVITY_LIMIT_MS / (60 * 1000)
      : 120;

    timeLimitInput.value = defaultMinutes;

    // Set default notification toggle
    notificationsToggle.checked = data.NOTIFICATIONS_ENABLED !== false;
  });

  // Save settings
  document.getElementById("saveBtn").addEventListener("click", () => {
    const minutes = parseInt(timeLimitInput.value);
    const ms = minutes * 60 * 1000;
    const notificationsEnabled = notificationsToggle.checked;

    chrome.storage.sync.set({
      INACTIVITY_LIMIT_MS: ms,
      NOTIFICATIONS_ENABLED: notificationsEnabled
    }, () => {
      alert("Settings saved!");
    });
  });
});
